  # Importando o módulo do sqlite3 para manipularmos o banco de dados SQLITE3
import sqlite3

# Importando o módulo do sqlite3 e a classe Error para exibir mensagens de erro
from sqlite3 import Error

# Importando o arquivo schema.py para criar as tabelas do banco de dados
import schema

# Importando o arquivo tabelas para manipular as informações nelas (CRUD)
# Criar, atualizar, excluir, e pesquisar.
import tabelas

# Importando o o arquivo cores.py, a classe Cores para colocar cores nos textos
from cores import Cores

# tempo em segundos informando dentro do parênteses
from time import sleep

def query(): # definindo as querys para mostrar as avaliações
  print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tPESQUISAS ESPECÍFICAS\n\n{Cores.ENDC}')    
  print(f"{Cores.BOLD}{Cores.WARNING}1.{Cores.White} Selecionar notas por faixas{Cores.ENDC}")
  print(f"{Cores.BOLD}{Cores.WARNING}2.{Cores.White} Pesquisar serviços sem avaliaçoes{Cores.ENDC}")
  print(f"{Cores.BOLD}{Cores.WARNING}3.{Cores.White} Usuários não atendidos{Cores.ENDC}")
  print(f"{Cores.BOLD}{Cores.WARNING}4.{Cores.White} Sair{Cores.ENDC}")  
  selecaoquery=10
  while selecaoquery < 1 or selecaoquery >4:
          selecaoquery = int(input('\n\n\nSelecione uma opção: ')) 
          if selecaoquery < 1 or selecaoquery >4:
                print (f"\n\t{Cores.BOLD}{Cores.LightYellow}ENTRADA INCORRETA!!! INSIRA UM VALOR REFERENTE AO MENU!!!\n\n{Cores.ENDC}")

  c = conn.cursor()
  if selecaoquery==1: #usuario define a faixa de pesquisa das notas
    limpar() 
    print(f'{Cores.BOLD}{Cores.Yellow}\nSELECIONAR POR FAIXAS DE NOTAS\n{Cores.ENDC}')   
    minimo = int(input('Selecione a nota mínima: '))  
    maximo=0
    while minimo > maximo:
          maximo = int(input('Selecione a nota máxima: ')) 
          if minimo > maximo:
                print (f"\n\t{Cores.BOLD}{Cores.LightYellow}ENTRADA INCORRETA!!! A NOTA MÁXIMA NÃO PODE SER MENOR QUE A MÍNIMA!!!\n\n{Cores.ENDC}") 
    faixa=(minimo,maximo)
    c.execute("SELECT * FROM avaliacoes WHERE nota>=? and nota<=?;",faixa)   
    resultado = c.fetchall()
    conn.commit()    
    limpar()   
    print(f'{Cores.BOLD}{Cores.Yellow}\nSELECIONAR POR FAIXAS DE NOTAS\n{Cores.ENDC}')           
    print(c.fetchall())

    if resultado:

                print(f"{Cores.BOLD}{Cores.OKGREEN}")
                print("{:<15} {:<15} {:<15} {:<15} {:<15} {:<15}".format(
                    "idAVALIAÇÃO","idcliente","idreserva","idservico", "NOTA", "DATA DA AVALIAÇÃO"
                        ))
                print(f"{Cores.ENDC} ")

                for item in range(len(resultado)):
                    print("{:<15} {:<15} {:<15} {:<15} {:<15} {:<15}  ".format(
                        resultado[item][0], resultado[item][1],
                        resultado[item][2], resultado[item][3], resultado[item][4], resultado[item][5]
                        ))       
    else:
 
       print(f'{Cores.BOLD}{Cores.Yellow }\nNÃO FORAM ENCONTRADOS REGISTROS NESSAS FAIXAS!!!{Cores.ENDC}')                                 
    conn.commit()    
    c = conn.cursor()

  elif selecaoquery==2: 
    c.execute("select clientes.nome,clientes.idclient,avaliacoes.idavaliacao,avaliacoes.idservico,avaliacoes.nota,avaliacoes.data_avaliacao from  clientes inner join avaliacoes on clientes.idclient = avaliacoes.idclient where avaliacoes.nota = '' ;")   


    resultado = c.fetchall()
    conn.commit() 
    limpar()   
    print(f'{Cores.BOLD}{Cores.Yellow}\nPESQUISAR SERVIÇOS SEM AVALIAÇÕES{Cores.ENDC}')         
    print(c.fetchall())
    if resultado:


                print(f"{Cores.BOLD}{Cores.OKGREEN}")
                print("{:<15} {:<15} {:<15} {:<15} {:<15} {:<15} ".format(
                    "nome","idcliente","idavaliacao","idserviço","nota",'data da avaliação'
                        ))
                print(f"{Cores.ENDC} ")

                for item in range(len(resultado)):
                    print("{:<15} {:<15} {:<15} {:<15} {:<15} {:<15}   ".format(
                        resultado[item][0], resultado[item][1],
                        resultado[item][2],resultado[item][3],resultado[item][4],resultado[item][5]
                        ))   
  elif selecaoquery==3: 
    c.execute("select clientes.nome,clientes.idclient,reservas.idreserva,reservas.data_entrada,reservas.data_saida from  clientes inner join reservas on clientes.idclient = reservas.idclient where data_entrada = '' ;")   


    resultado = c.fetchall()
    conn.commit()    
    print(c.fetchall())
    limpar()   
    print(f'{Cores.BOLD}{Cores.Yellow}\nCLIENTES QUE AINDA NÃO FORAM ATENDIDOS{Cores.ENDC}')    
    if resultado:


                print(f"{Cores.BOLD}{Cores.OKGREEN}")
                print("{:<15} {:<15} {:<15} {:<20} {:<15} ".format(
                    "Nome","Idcliente","Idreserva","Data de entrada","Data de saída"
                        ))
                print(f"{Cores.ENDC} ")

                for item in range(len(resultado)):
                    print("{:<15} {:<15} {:<15} {:<20} {:<15}   ".format(
                        resultado[item][0], resultado[item][1],
                        resultado[item][2],resultado[item][3],resultado[item][4]
                        ))                               
  elif selecaoquery==4: 
        None
  input(
                    f"{Cores.BOLD}{Cores.OKBLUE}\n\nPressione <ENTER> para retornar ...{Cores.ENDC}"
              )
      
              
#Menu de opções Principais----------------------------
def menu():
 limpar()
 print(52 * f'{Cores.White}¨{Cores.ENDC}') #Template cabeçalho ----------------------------
 print(f"{Cores.BOLD}{Cores.Cyan}   *** - Hotel Cafiornia - um hotel diferente ***\n{Cores.ENDC}")   
 print(52 * f'{Cores.White }¨{Cores.ENDC}') #Template cabeçalho 
 print(f"{Cores.BOLD}{Cores.Yellow}\t\t\t***--  MENU DE OPÇÕES --***\n{Cores.ENDC}")   
 print(52 * f'{Cores.White }¨{Cores.ENDC}') #Template cabeçalho 
 print("\n")
 #Template Opções do Menu ----------------------------
 print(f"{Cores.BOLD}{Cores.WARNING}1.{Cores.White} Clientes{Cores.ENDC}")
 print(f"{Cores.BOLD}{Cores.WARNING}2.{Cores.White} Servicos{Cores.ENDC}")
 print(f"{Cores.BOLD}{Cores.WARNING}3.{Cores.White} Reservas{Cores.ENDC}")
 print(f"{Cores.BOLD}{Cores.WARNING}4.{Cores.White} Avaliações{Cores.ENDC}")
 print(f"{Cores.BOLD}{Cores.WARNING}5.{Cores.White} Pesquisas específicas{Cores.ENDC}") 
 print(f"{Cores.BOLD}{Cores.WARNING}6.{Cores.White} Sair\n\n{Cores.ENDC}")
 print(f"{Cores.OKBLUE}" + 20 * '-' + 12 * '*' + 20 * '-' + f"{Cores.ENDC}")
 print(f"\t\t\t{Cores.OKBLUE}" + 26 * '-' + f"{Cores.ENDC}")
 selecao=100
 while selecao>6 or selecao<1:
          selecao = int(input('\n\nSelecione uma opção: ')) 
          if selecao>6 or selecao<1:
                print (f"\n\t{Cores.BOLD}{Cores.LightYellow}ENTRADA INCORRETA!!! INSIRA UM VALOR REFERENTE AO MENU!!!\n\n{Cores.ENDC}")
 return selecao

#Submenu de opções ---------------------------------
def submenu(tabela):
 limpar() # limpa a tela sempre que o submenu for chamado
 #Template cabeçalho ----------------------------
 print(52 * '*')
 print(f"{Cores.BOLD}{Cores.OKBLUE}\t\t\t\t*** Opção {tabela} ***{Cores.ENDC}")
 print(52 * '*')
 print('\n')
 #Template Opções do submenu ----------------------------
 print(f"{Cores.BOLD}{Cores.WARNING}0. {Cores.UNDERLINE}Retornar ao menu principal{Cores.ENDC}")
 print(f"{Cores.BOLD}{Cores.WARNING}1.{Cores.White} Inserir em {tabela}")
 print(f"{Cores.BOLD}{Cores.WARNING}2.{Cores.White} Atualizar dados dos {tabela}")
 print(f"{Cores.WARNING}3.{Cores.White} Exibir dados dos {tabela}")
 print(f"{Cores.BOLD}{Cores.WARNING}4.{Cores.White} Pesquisar com Filtros em {tabela}")
 print(f"{Cores.BOLD}{Cores.WARNING}5.{Cores.White} Excluir dados dos {tabela}{Cores.ENDC}")
 print(f"\n\n{Cores.OKBLUE}" + 20 * '-' + 12 * '*' + 20 * '-' + f"{Cores.ENDC}")
 print(f"\t\t\t{Cores.OKBLUE}" + 26 * '-' + f"{Cores.ENDC}")
 opcaosub=100
 while opcaosub > 5  :
          opcaosub = int(input('\n\nSelecione uma opção: ')) 
          if opcaosub > 5 :
                print (f"\n\t{Cores.BOLD}{Cores.LightYellow}ENTRADA INCORRETA!!! INSIRA UM VALOR REFERENTE AO MENU!!!\n\n{Cores.ENDC}")
                opcaosub = int(input('Selecione uma opção: '))
 return opcaosub


def criar_conexao(banco):
	"""Criando a conexão com o banco de dados Sqlite3."""
	# Variável conn inicializada para estabelecer a conexão com o banco
	conn = None
	# Tentará fazer a conexão com o banco de dados
	try:
		# Criando a conexão com o banco e salvando o objeto Connection na variável conn.
		conn = sqlite3.connect(banco)
		# Exibe a versão do Sqlite
		print(sqlite3.sqlite_version)
		# Sucesso na conexão. É retornado a conexão a quem chamou.
		return conn
	except Error as e:
		print(e)

# Função para limpar a tela antes de exibir a próxima instrução
def limpar():
    # Importando o módulo do sistema operacional (os) para usar instruções dele
    import os
    # Importando o módulo time para utilizar o método sleep que aguarda o 
    # tempo em segundos informando dentro do parênteses
    from time import sleep
    
    # Função para limpar a tela
    def screen_clear():
    # Para os sistemas operacionais: mac and linux(here, os.name is 'posix')
        if os.name == 'posix':
            _ = os.system('clear')
        else:
        # Para o sistema operacional windows
            _ = os.system('cls')
    # Aguarda 1 segundo para executar a próxima instrução
    sleep(1)
    # Chama a função de limpeza
    screen_clear()

if __name__ == '__main__':
 limpar() 
 print(52 * f'{Cores.LightYellow}¨{Cores.ENDC}') #Template cabeçalho
 print(f"{Cores.BOLD}{Cores.LightMagenta}\t\t    -- PROJETO DE ATENDIMENTOS --    \n{Cores.ENDC}")
 print(52 * f'{Cores.LightYellow}¨{Cores.ENDC}') #Template cabeçalho
 print(f"{Cores.BOLD}{Cores.OKBLUE}\nCriando o banco de dados se não existir ...{Cores.ENDC}")
 banco = 'Atendimento'
	# Executando a função de criação da conexão com o banco de dados
 conn = criar_conexao(banco)
 print(f"{Cores.BOLD}{Cores.LightGreen }\n\nCriando tabelas do banco de dados se não existirem ...\n{Cores.ENDC}")
	# Criar as tabelas do banco de dados
 schema.criar_tabelas(banco)
 sleep(2)
 input(
                    f"{Cores.BOLD}{Cores.OKBLUE}\n\nPressione <ENTER> para continuar ...{Cores.ENDC}"
              ) 
                   
 opcao = menu()

while opcao!=6: # laço para identificar e direcionar a escolha do menu 
    if opcao == 1:
	    tabela='clientes'
    elif opcao == 2:
      tabela='servicos'
    elif opcao == 3:
      tabela='reservas'
    elif opcao == 4:
        tabela='avaliacoes'
    elif opcao == 5:
        limpar()
        query()
        tabela='none'           
        opcaosub = 0          
    elif opcao<0 and opcao>5:
      print('Opção inválida opcao!')
      opcao=100
    else:
       None
    if tabela=='none':
           None  
    else: # laço para identificar e direcionar a escolha do SUBmenu 
        opcaosub = submenu(tabela)
        limpar()  

    if opcaosub == 1:
          tabelas.inserir(tabela, conn)
    elif opcaosub == 2:

          tabelas.atualizar(tabela, conn)
    elif opcaosub == 3:
            tabelas.pesquisar(tabela, conn)
    elif opcaosub == 4:
            tabelas.pesquisarUnico(tabela, conn)
    elif opcaosub == 5:
            tabelas.excluir(tabela, conn) 
                
    elif opcaosub == 0 :
            opcao=100
            print (f'{Cores.WARNING}        <--- RETORNANDO{Cores.ENDC}')  
            sleep(0.1)                   
            opcao=menu()     
               
            
    else:
      print('Opção inválida!')

    opcaosub=100
else:
    for i in range (3):
      limpar()   
      print(f'{Cores.BOLD}{Cores.Yellow}\n\tENCERRANDO O BANCO!!!\n\n{Cores.ENDC}')
      sleep(0.1)
      limpar()

    sleep(0.5)
    limpar()        
    print(f'{Cores.BOLD}{Cores.LightGreen}\n\tFINALIZADO!!!\n\n{Cores.ENDC}')    