# Importando o módulo sqlite3 para criarmos nosso banco e manipulá-lo.
from datetime import date
from cores import Cores
import os



############################################################################
#*****************************INSERIR DADOS*********************************

def limpar():
    # Importando o módulo do sistema operacional (os) para usar instruções dele
    import os
    # Importando o módulo time para utilizar o método sleep que aguarda o 
    # tempo em segundos informando dentro do parênteses
    from time import sleep
    
    # Função para limpar a tela
    def screen_clear():
    # Para os sistemas operacionais: mac and linux(here, os.name is 'posix')
        if os.name == 'posix':
            _ = os.system('clear')
        else:
        # Para o sistema operacional windows
            _ = os.system('cls')
    # Aguarda 1 segundo para executar a próxima instrução
    sleep(1)
    # Chama a função de limpeza
    screen_clear()

def inserir(tabela, conn):
    try:
        c = conn.cursor()
 #clientes---------------------------------
        if tabela == 'clientes':  
          os.system("clear")  #limpa a tela
          print(f'{Cores.BOLD}{Cores.Yellow}\n\tINSERIR NOVOS CLIENTES\n\n{Cores.ENDC}')      
          nome = input("Nome do cliente: ").title()
          cpf = input("CPF: ")
          endereco = input("Endereço: ").title()
          tel = input("Telefone: ").title()                        
          data = format(date.today(),'%d-%m-%Y')
          clientenovo = (nome, cpf, endereco,tel, data)
          c.execute("INSERT INTO clientes(nome, cpf, endereco,tel, data) VALUES (?,?,?,?,?);", clientenovo)
          conn.commit()  # grava no BD
          print(
             f"{Cores.BOLD}{Cores.OKGREEN}Inserção com sucesso em {tabela}.{Cores.ENDC}") 

#serviços---------------------------------
        if tabela == 'servicos':  
            os.system("clear")  #limpa a tela
            print(f'{Cores.BOLD}{Cores.Yellow}\n\tINSERIR NOVOS SERVIÇOS\n\n{Cores.ENDC}')        
            descricao = input("Nome do serviço: ").title()
            valor = input("Insira o valor do serviço R$: ").title()  #VAMOS TIRAR O VALOR DO SERVIÇO?             
            criado_em = date.today()
            serviconovo = (descricao,valor,criado_em)
            c.execute("INSERT INTO servicos (descricao, valor , data ) VALUES (?,?,?);", serviconovo)
            conn.commit()  # grava no BD
            print(
            f"{Cores.BOLD}{Cores.OKGREEN}Inserção com sucesso em {tabela}.{Cores.ENDC}")
            input( f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}")

#reservas---------------------------------
        if tabela == 'reservas':  
            os.system("clear")  #limpa a tela
            print(f'{Cores.BOLD}{Cores.Yellow}\n\tINSERIR NOVAS RESERVAS\n\n{Cores.ENDC}')       
            idcliente = input("Insira o id do cliente: ")    #ENTRAR COM DADOS     
            data_entrada = input("Data de entrada: ")  #ENTRAR COM DADOS 
            data_saida = input("Data de saida: ")  #ENTRAR COM DADOS 
            criado_em = date.today()  #PEGA A DATA EM QUE FOI REGISTRADA
            valor = input("Valor da reserva R$: ")  #ENTRAR COM DADOS 
            reservanovo = (idcliente, data_entrada, data_saida, valor,
                           criado_em)
            c.execute("INSERT INTO reservas (idclient , data_entrada, data_saida, valor ,data_registro ) VALUES (?,?,?,?,?);", reservanovo)
            conn.commit()  # grava no BD
            #AVISO DE SUCESSO
            print(f"{Cores.BOLD}{Cores.OKGREEN}Inserção com sucesso em {tabela}.{Cores.ENDC}")
            input( f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}")
         

#avaliações---------------------------------
        if tabela == 'avaliacoes':  #INSERIR A AVALIAÇÃO DADA PELO CLIENTE
            os.system("clear")  #limpa a tela
        #serviço e cliente entram como chave estrangeira
            print(f'{Cores.BOLD}{Cores.Yellow}\n\tINSERIR NOVAS AVALIAÇÕES\n\n{Cores.ENDC}')    
            idcliente = input("Digite id do cliente: ")   #ENTRAR COM DADOS 
            idreserva = input("Digite id da reserva: ")   #ENTRAR COM DADOS
            idservico = input("Digite id do serviço: ")   #ENTRAR COM DADOS
            nota = input("Digite sua nota de 1 a 5: ")    #ENTRAR COM DADOS
            data_avaliacao = date.today()  #PEGA A DATA EM QUE FOI REGISTRADA
            avaliacoes=(idcliente,idreserva,idservico,nota,data_avaliacao)
        #inserir dados no BD
            c.execute("INSERT INTO avaliacoes (idclient,idreserva,idservico, nota , data_avaliacao) VALUES (?,?,?,?,?);", avaliacoes)
            conn.commit()  # grava no BD    

          #Aviso sucesso
            print(f"{Cores.BOLD}{Cores.OKGREEN}Inserção com sucesso em {tabela}.{Cores.ENDC}")  
            input( f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}") 

    #fim---------------------------------------------------
    except: #aviso de erro
        print(f"{Cores.BOLD}{Cores.FAIL}ERRO NA INSERÇÃO DE DADOS {tabela}.{Cores.ENDC}")
        input( f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}")



############################################################################
#*******************************ATUALIZAR DADOS*****************************



def atualizar(tabela, conn):
    try:
        c = conn.cursor()
#--------------------------clientes----------------------------------------------------
        if tabela == 'clientes':       
            pesquisar(tabela, conn)
            limpar()
            print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tATUALIZAR DADOS DOS CLIENTES\n{Cores.ENDC}')                
#Menuzinho com opções do que atualizar -----------------------------
            #Opções de atualizar           
            print(f"{Cores.WARNING}1.{Cores.ENDC} Nome{Cores.ENDC}")
            print(f"{Cores.WARNING}2.{Cores.ENDC} CPF{Cores.ENDC}")
            print(f"{Cores.WARNING}3.{Cores.ENDC} Endereço{Cores.ENDC}")
            print(f"{Cores.WARNING}4.{Cores.ENDC}{Cores.ENDC} telefone{Cores.ENDC}")
            print(f"{Cores.WARNING}5.{Cores.ENDC} Sair{Cores.ENDC}")   
            opcaoatt = input("Indique a informação que deseja atualizar: \n")           
        #opção att 1 --------------------------------------
            if opcaoatt=='1':
                x = input("Insira o id do nome a ser atualizado:")     
                novonome = input("Insira o novo nome:").title()
                att=(novonome,x)              
                c.execute("UPDATE clientes SET nome=? where idclient=?;",att)
                conn.commit()  # grava no BD
                
                #Aviso sucesso
                print(f"{Cores.BOLD}{Cores.OKGREEN}Atualização feita com sucesso em {tabela}.{Cores.ENDC}")
                input( f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}")

        #opção att 2 --------------------------------------
            if opcaoatt=='2':
                x = input("Insira o id do CPF a ser atualizado:").upper()       
                novocpf = input("Insira o novo CPF:").upper()
                att=(novocpf,x)              
                c.execute("UPDATE clientes SET cpf=? where idclient=?;",att)
                conn.commit()  # grava no BD
                
                #Aviso sucesso
                print(f"{Cores.BOLD}{Cores.OKGREEN}Atualização feita com sucesso em {tabela}.{Cores.ENDC}")
                input( f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}")

        #opção att 3 --------------------------------------
            if opcaoatt=='3':
                x = input("Insira o id do endereço a ser atualizado: ").upper()       
                novoendereco = input("Insira o novo endereço:").upper()
                att=(novoendereco,x)              
                c.execute("UPDATE clientes SET endereco=? where idclient=?;",att)
                conn.commit()  # grava no BD

                #Aviso sucesso
                print(f"{Cores.BOLD}{Cores.OKGREEN}Atualização feita com sucesso em {tabela}.{Cores.ENDC}")
                input( f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}")

        #opção att 4 --------------------------------------
            if opcaoatt=='4':
                x = input("Insira o id do telefone a ser atualizado:").upper()       
                novotel = input("Insira o novo telefone: ").upper()
                att=(novotel,x)              
                c.execute("UPDATE clientes SET tel=? where idclient=?;",att)
                conn.commit()  # grava no BD

                #Aviso sucesso
                print(f"{Cores.BOLD}{Cores.OKGREEN}Atualização feita com sucesso em {tabela}.{Cores.ENDC}")
                input( f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}")

          #opção att 5 --------------------------------------       
            if opcaoatt=='5':
                            print (f'{Cores.WARNING}        <--- RETORNANDO{Cores.ENDC}')
                            pass 


#--------------------------Serviços----------------------------------------------------


        if tabela == 'servicos':#ATUALIZAR SERVIÇOS
            pesquisar(tabela, conn)
            #cabeçalho -----------------------
            print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tATUALIZAR DADOS DOS SERVIÇOS\n{Cores.ENDC}')    
            #opções de atualizar
            print(f"\n\n{Cores.WARNING}1.{Cores.ENDC} Descrição{Cores.ENDC}")
            print(f"{Cores.WARNING}2.{Cores.ENDC} Valor{Cores.ENDC}")
            print(f"{Cores.WARNING}3.{Cores.ENDC} Data{Cores.ENDC}") 
            print(f"{Cores.WARNING}4.{Cores.ENDC} Sair{Cores.ENDC}")   
            opcaoatt = input("Indique a informação que deseja atualizar: ")  
        #SEPARAÇÃO VISUAL ----------------------
            print("\n")
            print(f"\t\t\t{Cores.OKBLUE}" + 26 * '-' + f"{Cores.ENDC}")
        #opção att 1 --------------------------------------
            if opcaoatt=='1':
                x = input("\nInsira o ID  da descrição que irá ser atualizado:").upper()       
                novadesc = input("Insira a nova descrição:").upper()
                att=(novadesc,x)              
                c.execute("UPDATE servicos SET descricao=? where idservico=?;",att)
                conn.commit()  # grava no BD

                #Aviso sucesso
                print(f"{Cores.BOLD}{Cores.OKGREEN}Atualização feita com sucesso em {tabela}.{Cores.ENDC}")
                input( f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}")

        #opção att 2 --------------------------------------            
            if opcaoatt=='2':
                x = input("\nInsira o id do valor que deseja atualizar: ").upper()       
                novovalor = input("Insira o novo valor:").upper()
                att=(novovalor,x)              
                c.execute("UPDATE servicos SET valor=? where idservico=?;",att)
                conn.commit()  # grava no BD

                #Aviso sucesso
                print(f"{Cores.BOLD}{Cores.OKGREEN}Atualização feita com sucesso em {tabela}.{Cores.ENDC}")
                input( f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}")

        #opção att 3 --------------------------------------
            if opcaoatt=='3':
                x = input("\nInsira o id da data a ser trocada:").upper()
                novadata = input("Insira a nova data: ").upper()
                att=(novadata,x)              
                c.execute("UPDATE servicos SET data=? where idservico=?;",att)
                conn.commit()  # grava no BD

                #Aviso sucesso
                print(f"{Cores.BOLD}{Cores.OKGREEN}Atualização feita com sucesso em {tabela}.{Cores.ENDC}")
                input( f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}")

            #opção att 4 --------------------------------------
            #chamar saida
            #Volta para o menu
            if opcaoatt=='4':
                            print (f'{Cores.WARNING}        <--- RETORNANDO{Cores.ENDC}')       
                            pass 

#--------------------------Reservas----------------------------------------------------


        if tabela == 'reservas':#ATUALIZAR RESERVAS
            pesquisar(tabela, conn)
            #cabeçalho
            print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tATUALIZAR DADOS DAS RESERVAS\n{Cores.ENDC}')    
            #opções de atualizar
            print(f"{Cores.WARNING}1.{Cores.ENDC} Data de Entrada{Cores.ENDC}")
            print(f"{Cores.WARNING}2.{Cores.ENDC} Data de Saida {Cores.ENDC}")
            print(f"{Cores.WARNING}3.{Cores.ENDC}{Cores.ENDC} Valor{Cores.ENDC}")
            print(f"{Cores.WARNING}4.{Cores.ENDC} Sair{Cores.ENDC}")   
            opcaoatt = input("\nIndique a informação que deseja atualizar: ") 
        #SEPARAÇÃO VISUAL ----------------------
            print("\n")
            print(f"\t\t\t{Cores.OKBLUE}" + 26 * '-' + f"{Cores.ENDC}")

        #opção att 1 --------------------------------------
            if opcaoatt=='1':
                x = input("\nInsira o id da data de entrada a ser atualizado:").upper()       
                novo_dtentrada = input("Insira a nova data de entrada:").upper()
                att=(novo_dtentrada,x)              
                c.execute("UPDATE reservas SET data_entrada=? where idcliente=?;",att)
                conn.commit()  # grava no BD

                #Aviso sucesso
                print(f"{Cores.BOLD}{Cores.OKGREEN}Atualização feita com sucesso em {tabela}.{Cores.ENDC}")
                input( f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}")

          #opção att 2 --------------------------------------
            if opcaoatt=='2':
                x = input("\nInsira o id da data de saida a ser atualizado:").upper()       
                novo_dtsaida = input("Insira a nova data de saida: ").upper()
                att=(novo_dtsaida,x)              
                c.execute("UPDATE reservas SET data_saida=? where idcliente=?;",att)
                conn.commit()  # grava no BD

                #Aviso sucesso
                print(f"{Cores.BOLD}{Cores.OKGREEN}Atualização feita com sucesso em {tabela}.{Cores.ENDC}")
                input( f"{Cores.BOLD}{Cores.OKBLUE}\\nPressione <ENTER> para continuar ...{Cores.ENDC}")

#opção att 3 --------------------------------------
            if opcaoatt=='3':
                x = input("\nInsira o id do endereço a ser atualizado:").upper()       
                novoendereco = input("Insira o novo endereço:").upper()
                att=(novoendereco,x)              
                c.execute("UPDATE reservas SET valor=? where idcliente=?;",att)
                conn.commit()  # grava no BD

                #Aviso sucesso
                print(f"{Cores.BOLD}{Cores.OKGREEN}Atualização feita com sucesso em {tabela}.{Cores.ENDC}")
                input( f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}")

#opção att 4 --------------------------------------
            #chamar saida
            #Volta para o menu
            if opcaoatt=='4':
                            print (f'{Cores.WARNING}        <--- RETORNANDO{Cores.ENDC}')         
                            pass 


#--------------------------avaliações----------------------------------------------------


        if tabela == 'avaliacoes':#ATUALIZAR AVALIAÇOES
            pesquisar(tabela, conn)
            #cabeçalho
            print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tATUALIZAR DADOS DAS AVALIAÇÕES\n{Cores.ENDC}')    
#AVISO!!!!!!!!!!!!!!! --------------------------------------
            #Não é possivel atualizar avaliações -- mostrar aviso
            print(f"\t\t{Cores.WARNING}{Cores.ENDC} \nO HOTEL CAFIORNIA -- não pode mudar/alterar as avaliações dos clientes! {Cores.ENDC}")
            
#opção att 1 --------------------------------------             
            #chamar saida
            #Volta para o menu # grava no BD
            if opcaoatt=='1':
                            print (f'{Cores.WARNING}        <--- RETORNANDO{Cores.ENDC}')          
                            pass 
 
    #fim---------------------------------------------------
    except: #aviso de erro
      print(f"{Cores.BOLD}{Cores.FAIL}\nERRO NA INSERÇÃO DE DADOS {tabela}.{Cores.ENDC}")
        
      input( f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}")
        


############################################################################
#******************************MOSTRAR  DADOS***************************



def pesquisar(tabela, conn):
    try:
        c = conn.cursor()
        #cabeçalho ------------------

#--------------------------Clientes-----------------------------------------------  

        if tabela == 'clientes':#PESQUISAR CLIENTES

            c.execute("SELECT * FROM clientes;")
            resultado = c.fetchall()  
            print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tMOSTRAR DADOS DOS CLIENTES\n\n{Cores.ENDC}')                      
            print(c.fetchall())

            if resultado: 
    #Mostrar itens do cliente-----------------------------------------------------
                print(f"{Cores.BOLD}{Cores.Red}")
                print(" {:<3} |  {:<25} |  {:<15} |  {:<35} |  {:<15} |  {:<10} ".format(
                    "ID", "NOME", "CPF", "ENDEREÇO","TELEFONE","DATA DE INSERÇÃO")) # titulo dos dados apresentados -------
                print(130 * '*' + f"{Cores.ENDC} ")

    #mostrar cada item de acordo com seu tamanho
                for item in range(len(resultado)):
                    print(" {:<3} |  {:<25} |  {:<15} |  {:<35} |  {:<15} |  {:<10} ".format(
                        resultado[item][0], resultado[item][1],
                        resultado[item][2], resultado[item][3],
                        resultado[item][4], resultado[item][5]))
                input(
                    f"{Cores.BOLD}{Cores.OKBLUE}Pressione <ENTER> para continuar ...{Cores.ENDC}"
                )
            else:
                print(
                    f"{Cores.BOLD}{Cores.FAIL}Não foram encontrados registros.{Cores.ENDC}")


#--------------------------Serviços-----------------------------------------------


        if tabela == 'servicos': #PESQUISAR SERVIÇOS
            c.execute("SELECT * FROM servicos;")
            resultado = c.fetchall()
            print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tMOSTRAR DADOS DOS SERVIÇOS\n\n{Cores.ENDC}')                
            print(c.fetchall())

            if resultado:
    #Mostrar itens do SErviços-----------------------------------------------------
                print(f"{Cores.BOLD}{Cores.Red}")
                print("{:<3} | {:<40} | {:<6} | {:<10} ".format(
                    "ID", "DESCRIÇÃO", "VALOR", "DATA"))
                print(90 * '*' + f"{Cores.ENDC} ")

                for item in range(len(resultado)):
                    print("{:<3} | {:<40} | {:<6} | {:<10} ".format(
                        resultado[item][0], resultado[item][1],
                        resultado[item][2], resultado[item][3]))
                input(
                    f"{Cores.BOLD}{Cores.OKBLUE}Pressione <ENTER> para continuar ...{Cores.ENDC}"
                )
            else:
                print(
                    f"{Cores.BOLD}{Cores.FAIL}Não foram encontrados registros.{Cores.ENDC}"
                )


#--------------------------Reservas-------------------------------------------


        if tabela == 'reservas':#PESQUISAR RESERVAS
            c.execute("SELECT * FROM reservas;")

            resultado = c.fetchall()
            print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tMOSTRAR DADOS DAS RESERVAS\n\n{Cores.ENDC}')                
            print(c.fetchall())

            if resultado:

                print(f"{Cores.BOLD}{Cores.Red}")
                print("{:<10}| {:<10}| {:<15}| {:<14}| {:<7}| {:<16}".format(
                    "ID RESERVA","ID CLIENTE", "DATA DE ENTRADA", "DATA DE SAIDA", "PREÇO", "DATA DE INSERÇÃO"))
                print(90 * '*' + f"{Cores.ENDC} ")

                for item in range(len(resultado)):
                    print("{:<10}| {:<10}| {:<15}| {:<14}| {:<7}| {:<16}".format(
                        resultado[item][0], resultado[item][1],
                        resultado[item][2], resultado[item][3],
                        resultado[item][4], resultado[item][5]))
                input(
                    f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}"
                )
            else:
                print(
                    f"{Cores.BOLD}{Cores.FAIL}Não foram encontrados registros.{Cores.ENDC}"
                )

#--------------------------Avaliações-----------------------------------------------


        if tabela == 'avaliacoes':# PESQUISAR AVALIAÇOES
            c.execute("SELECT * FROM avaliacoes;")

            resultado = c.fetchall()
            print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tMOSTRAR DADOS DAS AVALIAÇÕES\n\n{Cores.ENDC}')                
            print(c.fetchall())

            if resultado:
                print(f"{Cores.BOLD}{Cores.Red}")
                print("{:<13}| {:<11}| {:<10}| {:<10}| {:<6}| {:<18}".format(
                    "ID AVALIAÇÃO","ID CLIENTE","ID RESERVA","ID SERVIÇO", "NOTA", "DATA DA AVALIAÇÃO"
                        ))
                print(90 * '*' + f"{Cores.ENDC} ")

                for item in range(len(resultado)):
                    print("{:<13}| {:<11}| {:<10}| {:<10}| {:<6}| {:<18}".format(
                        resultado[item][0], resultado[item][1],
                        resultado[item][2], resultado[item][3], resultado[item][4], resultado[item][5]
                        ))
                input(
                    f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}"
                )
            else:
                print(
                    f"{Cores.BOLD}{Cores.FAIL}Não foram encontrados registros.{Cores.ENDC}"
                )                
    #fim---------------------------------------------------
    except: #aviso de erro
        print(f"{Cores.BOLD}{Cores.FAIL}ERRO NA PESQUISA DE DADOS {tabela}.{Cores.ENDC}")
        input( f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}")



####################################################################################
#****************************PESQUISA DETALHADA DE DADOS***************************



def pesquisarUnico(tabela, conn):
    try:
        c = conn.cursor()
        os.system("clear")  #limpa a tela

#--------------------------Clientes-----------------------------------------------


        if tabela == 'clientes':#PESQUISA DETALHADA DE CLIENTES

            #CABEÇALHO - SEPARAÇÃO 
            #opçõe do menuzinho
            print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tPESQUISAR DADOS COM FILTROS EM CLIENTES\n\n{Cores.ENDC}')             
            print(f"{Cores.WARNING}1.{Cores.ENDC} Nome{Cores.ENDC}")
            print(f"{Cores.WARNING}2.{Cores.ENDC} CPF{Cores.ENDC}")
            print(f"{Cores.WARNING}3.{Cores.ENDC} Endereço{Cores.ENDC}")
            print(f"{Cores.WARNING}4.{Cores.ENDC}{Cores.ENDC} Telefone{Cores.ENDC}")
            print(f"{Cores.WARNING}5.{Cores.ENDC} Sair{Cores.ENDC}")   
            opcaoatt = input("ATRAVÉS DE QUAL INFORMAÇÃO FARÁ A BUSCA? ")  

            #SEPARAÇÃO VISUAL ----------------------
            print("\n")
            print(f"\t\t\t{Cores.OKBLUE}" + 26 * '-' + f"{Cores.ENDC}")  

    #opção att 1 --------------------------------------
            if opcaoatt=='1':    
                descricao = input("\n\nINSIRA PARA PESQUISAR POR NOME: ").title()
                c.execute("SELECT * FROM clientes WHERE nome like (?);",
                      ('%' + descricao + '%', ))
                conn.commit()

    #opção att 2 --------------------------------------
            if opcaoatt=='2':
                descricao = input("INSIRA PARA PESQUISAR POR CPF: ").title()
                c.execute("SELECT * FROM clientes WHERE cpf like (?);",
                      ('%' + descricao + '%', ))
                conn.commit()

    #opção att 3 --------------------------------------
            if opcaoatt=='3':
                descricao = input("INSIRA PARA PESQUISAR POR ENDEREÇO: ").title()
                c.execute("SELECT * FROM clientes WHERE endereco like (?);",
                      ('%' + descricao + '%', ))
                conn.commit()

    #opção att 4 --------------------------------------
            if opcaoatt=='4':
                descricao = input("INSIRA PARA PESQUISAR POR TELEFONE: ").title()
                c.execute("SELECT * FROM clientes WHERE tel like (?);",
                      ('%' + descricao + '%', ))
                conn.commit()     
            resultado = c.fetchall()
            limpar()
            print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tPESQUISAR DADOS COM FILTROS EM CLIENTES\n\n{Cores.ENDC}')            
            print(c.fetchall())           
            if resultado:
                print(f"{Cores.BOLD}{Cores.Red}")
                print("{:<3} |  {:<25} |  {:<15} |  {:<35} |  {:<15} |  {:<10} ".format(
                    "ID", "NOME", "CPF", "ENDEREÇO","TELEFONE","DATA DE INSERÇÃO"))
                print(f"{Cores.ENDC} ")
                for item in range(len(resultado)):
                    print("{:<3} |  {:<25} |  {:<15} |  {:<35} |  {:<15} |  {:<10} ".format(
                        resultado[item][0], resultado[item][1],
                        resultado[item][2], resultado[item][3],
                        resultado[item][4], resultado[item][5]))
                input(
                    f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}"
                )
            else:
                print(
                    f"{Cores.BOLD}{Cores.FAIL}Não foram encontrados registros.{Cores.ENDC}"
                )


#--------------------------Serviços-----------------------------------------------


        if tabela == 'servicos':#PESQUISA DETALHADA DE SERVIÇOS

        #CABEÇALHO - SEPARAÇÃO
        #opçõe do menuzinho
            print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tPESQUISAR DADOS COM FILTROS EM SERVIÇOS\n\n{Cores.ENDC}')            
            print(f"{Cores.WARNING}1.{Cores.ENDC} Descrição{Cores.ENDC}")
            print(f"{Cores.WARNING}2.{Cores.ENDC} Valor{Cores.ENDC}")
            print(f"{Cores.WARNING}3.{Cores.ENDC} Sair{Cores.ENDC}")   
            opcaoatt = input("ATRAVÉS DE QUAL INFORMAÇÃO FARÁ A BUSCA?: ")
            limpar()
            #SEPARAÇÃO VISUAL ----------------------
            print("\n")
            print(f"\t\t\t{Cores.OKBLUE}" + 26 * '-' + f"{Cores.ENDC}") 

    #opção att 1 --------------------------------------
            if opcaoatt=='1':
                descricao = input("INSIRA PARA PESQUISAR POR DESCRIÇÃO: ").title()
                c.execute("SELECT * FROM servicos WHERE descricao like (?);",
                      ('%' + descricao + '%', ))
                conn.commit()
    #opção att 2 --------------------------------------
            if opcaoatt=='2':
                descricao = input("INSIRA PARA PESQUISAR POR VALOR: ").title()
                c.execute("SELECT * FROM servicos WHERE valor like (?);",
                      ('%' + descricao + '%', ))
                conn.commit()
    #opção att 3
        #saida
        #chamar função

            resultado = c.fetchall()
            print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tPESQUISAR DADOS COM FILTROS EM SERVIÇOS\n\n{Cores.ENDC}')            
            print(c.fetchall())

            if resultado:
                print(f"{Cores.BOLD}{Cores.Red}")
                print("{:<3} | {:<40} | {:<6} | {:<10} ".format(
                    "ID SERVIÇO", "DESCRICAO", "VALOR", "DATA"))
                print(f"{Cores.ENDC} ")

                for item in range(len(resultado)):
                    print("{:<3} | {:<40} | {:<6} | {:<10} ".format(
                        resultado[item][0], resultado[item][1],
                        resultado[item][2], resultado[item][3]))

                input(
                    f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}"
                )
            else:
                print(
                    f"{Cores.BOLD}{Cores.FAIL}Não foram encontrados registros.{Cores.ENDC}"
                )
                        

#--------------------------reservas-----------------------------------------------


        if tabela == 'reservas':#PESQUISA DETALHADA DE RESERVAS

        #CABEÇALHO - SEPARAÇÃO       
        #opções do menuzinho
            print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tPESQUISAR DADOS COM FILTROS EM RESERVAS\n\n{Cores.ENDC}')            
            print(f"{Cores.WARNING}1.{Cores.ENDC} DATA DE ENTRADA{Cores.ENDC}")
            print(f"{Cores.WARNING}2.{Cores.ENDC} DATA DE SAIDA{Cores.ENDC}")
            print(f"{Cores.WARNING}3.{Cores.ENDC}{Cores.ENDC} VALOR{Cores.ENDC}")
            print(f"{Cores.WARNING}4.{Cores.ENDC} Sair{Cores.ENDC}")   
            opcaoatt = input("ATRAVÉS DE QUAL INFORMAÇÃO FARÁ A BUSCA?: ") 
            limpar()
        #SEPARAÇÃO VISUAL ----------------------
            print("\n")
            print(f"\t\t\t{Cores.OKBLUE}" + 26 * '-' + f"{Cores.ENDC}") 


      #opção att 1 --------------------------------------
            if opcaoatt=='1':
                descricao = input("INSIRA PARA PESQUISAR POR DATA DE ENTRADA: ").title()
                c.execute("SELECT * FROM reservas WHERE data_entrada like (?);",
                      ('%' + descricao + '%', ))
                conn.commit()

      #opção att 2 --------------------------------------
            if opcaoatt=='2':
                descricao = input("INSIRA PARA PESQUISAR POR DATA DE SAIDA: ").title()
                c.execute("SELECT * FROM reservas WHERE data_saida like (?);",
                      ('%' + descricao + '%', ))
                conn.commit()

      #opção att 3 --------------------------------------
            if opcaoatt=='3':
                descricao = input("INSIRA PARA PESQUISAR POR VALOR: R$ ").title()
                c.execute("SELECT * FROM reservas WHERE valor like (?);",
                      ('%' + descricao + '%', ))
                conn.commit()

      #opção att 4 --------------------------------------
            if opcaoatt=='4':
                descricao = input("INSIRA PARA PESQUISAR POR DESCRIÇÃO: ").title()
                c.execute("SELECT * FROM reservas WHERE nome like (?);",
                      ('%' + descricao + '%', ))
                conn.commit()
            resultado = c.fetchall()
            print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tPESQUISAR DADOS COM FILTROS EM RESERVAS\n\n{Cores.ENDC}')            
            print(c.fetchall())

      #mostra resultado
            if resultado:

                print(f"{Cores.BOLD}{Cores.Red}")
                print("{:<10}| {:<10}| {:<15}| {:<14}| {:<7}| {:<16}".format(
                    "ID RESERVA","ID CLIENTE", "DATA DE ENTRADA", "DATA DE SAIDA", "PREÇO", "DATA DE INSERÇÃO"))
                print(f"{Cores.ENDC} ")

                for item in range(len(resultado)):
                    print("{:<10}| {:<10}| {:<15}| {:<14}| {:<7}| {:<16}".format(
                        resultado[item][0], resultado[item][1],
                        resultado[item][2], resultado[item][3],
                        resultado[item][4], resultado[item][5]))
                
                input(
                    f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}"
                )
            else:
                print(
                    f"{Cores.BOLD}{Cores.FAIL}Não foram encontrados registros.{Cores.ENDC}"
                )

#-------------------------- Pesquisa Unica --------------------------------------------


        if tabela == 'avaliacoes':#PESQUISA DETALHADA DE AVALIAÇOES

        #CABEÇALHO - SEPARAÇÃO 
        #opções do menuzinho
            print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tPESQUISAR DADOS COM FILTROS EM AVALIAÇÕES\n\n{Cores.ENDC}')            
            print(f"{Cores.WARNING}1.{Cores.ENDC} ID {Cores.ENDC}")
            print(f"{Cores.WARNING}2.{Cores.ENDC} DATA DA AVALIAÇÃO {Cores.ENDC}")      
            print(f"{Cores.WARNING}3.{Cores.ENDC} NOTA {Cores.ENDC}")                     
            print(f"{Cores.WARNING}4.{Cores.ENDC} Sair{Cores.ENDC}")   
            opcaoatt = input("ATRAVÉS DE QUAL INFORMAÇÃO FARÁ A BUSCA?: ")
            limpar()
            #SEPARAÇÃO VISUAL ----------------------
            print("\n")
            print(f"\t\t\t{Cores.OKBLUE}" + 26 * '-' + f"{Cores.ENDC}")  

     #opção att 1 --------------------------------------
            if opcaoatt=='1':
                descricao = input("INSIRA PARA PESQUISAR POR id: ").title()
                c.execute("SELECT * FROM avaliacoes WHERE idavaliacao like (?);",
                      ('%' + descricao + '%', ))
                conn.commit()
      #opção att 2 --------------------------------------
            if opcaoatt=='2':
                descricao = input("INSIRA PARA PESQUISAR POR data: ").title()
                c.execute("SELECT * FROM avaliacoes WHERE data_avaliacao like (?);",
                      ('%' + descricao + '%', ))
                conn.commit()
      #opção att 3 --------------------------------------
            if opcaoatt=='3':
                descricao = input("INSIRA PARA PESQUISAR POR nota: ").title()
                c.execute("SELECT * FROM avaliacoes WHERE nota like (?);",
                      ('%' + descricao + '%', ))
                conn.commit()

            resultado = c.fetchall()
            print(f'{Cores.BOLD}{Cores.Yellow}{Cores.UNDERLINE}\n\tPESQUISAR DADOS COM FILTROS EM AVALIAÇÕES\n\n{Cores.ENDC}')            
            print(c.fetchall())

            if resultado:
                print(f"{Cores.BOLD}{Cores.Red}")
                print("{:<13}| {:<11}| {:<10}| {:<10}| {:<6}| {:<18}".format(
                    "ID AVALIAÇÃO","ID CLIENTE","ID RESERVA","ID SERVIÇO", "NOTA", "DATA DA AVALIAÇÃO"))
                print(f"{Cores.ENDC} ")

                for item in range(len(resultado)):
                    print("{:<13}| {:<11}| {:<10}| {:<10}| {:<6}| {:<18} ".format(
                        resultado[item][0], resultado[item][1],
                        resultado[item][2], resultado[item][3], resultado[item][4], resultado[item][5]
                        ))
                input(
                    f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}"
                )
            else:
                print(
                    f"{Cores.BOLD}{Cores.FAIL}Não foram encontrados registros.{Cores.ENDC}"
                )

    #aviso erro -----------
    except:
        print(f"{Cores.BOLD}{Cores.OKGREEN} ERRO EM PESQUISA DETALHADA {tabela}.{Cores.ENDC}")
        input(f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}")

#******************************EXCLUIR DADOS***************************
def excluir(tabela, conn):
    try:
        c = conn.cursor()
        os.system("clear")  #limpa a tela

#--------------------------Clientes-----------------------------------------------


        if tabela =='clientes':
            pesquisar(tabela, conn)
            x = input("Indique o id a excluir: ")
            values = (x, )
            c.execute("DELETE FROM clientes WHERE idclient =?;", values)
            conn.commit()  # grava no BD

            print(
            f"{Cores.BOLD}{Cores.OKGREEN}Exclusão realizado com sucesso em {tabela}.{Cores.ENDC}"
        ) 

#--------------------------Serviços-----------------------------------------------


        if tabela =='servicos':
            pesquisar(tabela, conn)
            x = input("Indique o id a excluir: ")
            values = (x, )
            c.execute("DELETE FROM servicos WHERE idservico =?;", values)
            conn.commit()  # grava no BD

            print(
            f"{Cores.BOLD}{Cores.OKGREEN}Exclusão realizado com sucesso em {tabela}.{Cores.ENDC}"
        ) 

#--------------------------Reservas-----------------------------------------------


        if tabela =='reservas':
            pesquisar(tabela, conn)
            x = input("Indique o id a excluir: ")
            values = (x, )
            c.execute("DELETE FROM reservas WHERE idreserva =?;", values)
            conn.commit()  # grava no BD

            print(
            f"{Cores.BOLD}{Cores.OKGREEN}Exclusão realizado com sucesso em {tabela}.{Cores.ENDC}"
        ) 

#--------------------------Avaliação-----------------------------------------------


        if tabela =='avaliacoes':
            pesquisar(tabela, conn)
            x = input("Indique o id a excluir: ")
            values = (x, )
            c.execute("DELETE FROM avaliacoes WHERE idavaliacao =?;", values)
            conn.commit()  # grava no BD
    #aviso sucesso -----------
            print(
            f"{Cores.BOLD}{Cores.OKGREEN}Exclusão realizado com sucesso em {tabela}.{Cores.ENDC}"
        )  
    #aviso de erro -----------
    except:
        print(f"{Cores.BOLD}{Cores.OKGREEN}Erro na operação de exclusao em {tabela}.{Cores.ENDC}")
        input(f"{Cores.BOLD}{Cores.OKBLUE}\nPressione <ENTER> para continuar ...{Cores.ENDC}")