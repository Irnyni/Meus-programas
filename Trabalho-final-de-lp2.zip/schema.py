import sqlite3
from sqlite3 import Error
from cores import Cores


def criar_tabelas(banco):
	# Definindo a conexão com o BD chamado
 conn = sqlite3.connect(banco)
 c = conn.cursor()

 try: 
      # Criar tabela clientes----------------------------------------------------------
      c.execute("""CREATE TABLE if not exists clientes ( 
        idclient integer primary key,
        nome text,
        cpf text,
        endereco text,
        tel int ,
        data data)""")
      conn.commit()
      #adicionar valores tabela clientes  ----------------------------------------------------------
      c.execute("INSERT INTO clientes  VALUES (1,'Julio', 12563289923,'Rua das papoulas 35','(11) 2577-9876', '22-11-2020'),('2','Sofia Costa', 15585681826,'Rua 2 de Dezembro 217, Vila Toscana','(11)-93465-2777', '25-09-2021'),('3','Gentil Souza ', 19954798855,'Avenida Cedro 57 Rio largo','(11)-6788-9900','27-11-2021'),(4,'Beth Silveira Gomes',15865692222, 'Rua Goias 737','(35)-98569-6744','05-12-2021'), (5,'Giuliano Mendes Silva',12969612142, 'Rua Santa Trindade 226','(12)-98139-4712','09-10-2021'), (6,'Joseph loius',21769992142, 'Rua dos pinheiros 38','(11)94712-6633','11-10-2021'),(7,'Stephany Silva',39023855281, 'Rua Gasparini 3223','(22)-91125-2955','17-10-2021'), (11,'Eva da Silva',12969612142, 'Rua 25 de Dezembro 1233','(12)-98139-5677','20-10-2021');")
      conn.commit()

      # Criar tabela serviços ----------------------------------------------------------
      c.execute("""CREATE TABLE if not exists servicos (
      idservico integer primary key,
      descricao text,
      valor decimal (4,2),
      data data)""")
      conn.commit()

      #adicionar valores tabela serviços----------------------------------------------------------
      c.execute("INSERT INTO servicos  VALUES (1,'Spa','250','22-07-2012'),(2,'Massagem','100.00','25-01-2012'),(3,'Jantar Menu Completo para Casal','75.00','27-07-2012'),(4,'Piscina Aquecida','30.00','21-07-2012'),(5,'Café adicional','25.00','21-08-2012'),(6,'Choffer','350.00','21-07-2012'),(7,'Champagne unid','50.00','22-07-2212');")      
      conn.commit()  

      # Criar tabela Reservas   ---------------------------------------------------------- 
      c.execute("""CREATE TABLE if not exists reservas (
        idreserva integer primary key,
        idclient integer,
        data_entrada data default '',
        data_saida data default '',
        valor decimal (4,2) default '',
        data_registro data,
        FOREIGN KEY(idclient) REFERENCES clientes(idclient))""")
      conn.commit()

      #adicionar valores tabela Reservas ----------------------------------------------------------
      c.execute("INSERT INTO reservas  VALUES (1,3,'','','','23-05-2020'),(2,2,'28-10-2020','30-10-2020','250','23-05-2020'), (3, 1, '20-04-2021', '27-08-2021', '750', '20-08-2021'), (4, 4, '12-05-2021', '20-05-2021', '800', '12-05-2021'), (5, 5, '21-05-2021', '24-05-2021', '280', '21-05-2021'), (6,6, '', '', '', '03-06-2021') ;")      
      conn.commit()    

      #Criar tabelas Avaliaçoes  ----------------------------------------------------------  
      c.execute("""CREATE TABLE if not exists avaliacoes (
        idavaliacao integer primary key,
        idclient integer,
        idreserva integer,
        idservico integer,
        nota int not null default '',
        data_avaliacao data,
        FOREIGN KEY(idclient) REFERENCES clientes(idclient),
        FOREIGN KEY(idreserva) REFERENCES reservas(idreserva),
        FOREIGN KEY(idservico) REFERENCES servicos (idservico))""")
      conn.commit()  

      #adicionar valores tabela avaliacoes ----------------------------------------------------------
      c.execute("INSERT INTO avaliacoes  VALUES (1,2,1,5,'',''),(2,6,7,4,'2','29-05-2020'),(5,3,4,4,'',''),(12,3,4,4,'4','29-05-2020'),(7,3,4,4,'2','29-05-2020'),(8,6,4,4,'1','29-05-2020'),(9,7,4,4,'1','29-05-2020'),(11,3,4,4,'5','29-05-2020'),(13,11,8,5,'','');")      
      conn.commit()    

      return print(f"{Cores.BOLD}{Cores.LightGreen}\n\nTabelas criadas com sucesso!\n\n{Cores.ENDC}")

 except Error as e:
		 print(e)