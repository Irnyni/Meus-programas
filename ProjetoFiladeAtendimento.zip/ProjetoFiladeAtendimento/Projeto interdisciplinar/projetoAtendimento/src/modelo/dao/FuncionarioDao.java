package modelo.dao;

public class FuncionarioDao {

}
