package modelo.dao;

public class PessoaDao {

}
