package modelo.dao;

public class ClienteDao {

}
