package modelo.entidade;

public class Cliente extends Pessoa {

}
