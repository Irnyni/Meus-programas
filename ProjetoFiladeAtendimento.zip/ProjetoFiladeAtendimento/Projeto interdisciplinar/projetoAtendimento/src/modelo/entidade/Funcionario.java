package modelo.entidade;

public class Funcionario extends Pessoa {

}
