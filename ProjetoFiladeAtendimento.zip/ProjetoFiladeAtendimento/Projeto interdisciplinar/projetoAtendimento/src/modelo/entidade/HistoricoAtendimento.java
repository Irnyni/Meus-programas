package modelo.entidade;

public class HistoricoAtendimento {

}
