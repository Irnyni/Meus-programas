package modelo.entidade;

public class Avaliacao {
	private int nota;
	private String comentario;

	// Getters
	public String getComentario() {
		return comentario;
	}

	public int getNota() {
		return nota;
	}

	//Setters
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	public void setNota(int nota) {
		this.nota = nota;
	}




}